import 'package:flutter/material.dart';
import 'package:xd/branch/FeedbackColombo.dart';

class BranchNet extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black38,
        title: Text(
          "Branch Network",
          style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
        ),
        leading: Container(
          child: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (BuildContext context) {
                // return dashboard();
                //dashboard page එකට direct වෙන්න ඔින
              }));
            },
          ),
        ),
      ),
      body: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          color: Colors.black38,
          child: Container(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                //Colombo Branch
                Container(
                  height: 150,
                  width: 300,
                  child: Container(
                    height: 150,
                    width: 300,
                    child: RaisedButton(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(10))),
                      onPressed: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (BuildContext context) {
                          return Colombo();
                        }));
                      },
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          Text(
                            "Hyde Park Corner",
                            style: TextStyle(
                                fontSize: 30, fontWeight: FontWeight.bold),
                          ),
                          Row(
                            children: <Widget>[
                              Icon(Icons.phone),
                              Text(
                                "0713216548",
                                style: TextStyle(
                                    fontSize: 24, fontStyle: FontStyle.normal),
                              ),
                            ],
                          ),
                          Row(
                            children: <Widget>[
                              Icon(Icons.location_on),
                              Text(
                                  "No 123, Hyde park corner, Colombo 2, Sri Lanka")
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                ),

                //මහනුවර ශාඛාව
                Container(
                  height: 150,
                  width: 300,
                  child: Container(
                      height: 150,
                      width: 300,
                      child: RaisedButton(
                        shape: RoundedRectangleBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(10))),
                        onPressed: () {
                          Navigator.push(context, MaterialPageRoute(
                              builder: (BuildContext context) {
                            return Colombo();
                          }));
                        },
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: <Widget>[
                            Text(
                              "Kandy Branch",
                              style: TextStyle(
                                  fontSize: 30, fontWeight: FontWeight.bold),
                            ),
                            Row(
                              children: <Widget>[
                                Icon(Icons.phone),
                                Text("08197122439",
                                    style: TextStyle(
                                        fontSize: 24,
                                        fontStyle: FontStyle.normal)),
                              ],
                            ),
                            Row(
                              children: <Widget>[
                                Icon(Icons.location_on),
                                Text("No 320, Main street, Kandy, Sri Lanka")
                              ],
                            )
                          ],
                        ),
                      )),
                )
              ],
            ),
          )),
    );
  }
}
